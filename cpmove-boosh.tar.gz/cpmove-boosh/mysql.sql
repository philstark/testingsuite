-- cPanel mysql backup
GRANT USAGE ON *.* TO 'boosh'@'localhost' IDENTIFIED BY PASSWORD '*B867055C61BEA33BAB533EF0900D1B193FBE6844';
GRANT ALL PRIVILEGES ON `boosh\_%`.* TO 'boosh'@'localhost';
